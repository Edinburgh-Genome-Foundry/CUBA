These connectors are from the EMMA assembly standard ([Martella et al, Acs Syn Bio 2017](http://pubs.acs.org/doi/abs/10.1021/acssynbio.7b00016))

